#!/usr/bin/env sh

alias c="clear"
alias gs="git status"
alias gb="git branch -a"
alias gbc="git branch"
