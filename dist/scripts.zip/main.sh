#!/usr/bin/env sh

base_dir=$(dirname "$0")

[ -f "$base_dir/aliases.sh" ] && source "$base_dir/aliases.sh"